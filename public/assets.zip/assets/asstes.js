import MainLogo from "../assets/main-site-logo.jpg";
import facebookicon from "../assets/facebook-icon.png";
import googleicon from "../assets/google-icon.png";
import iphoneicon from "../assets/iphone-icon.png";
import Loginbanner1 from "../assets/Login-banner-1.png";
import Loginbanner2 from "../assets/Login-banner-2.png";
import Loginbanner3 from "../assets/Login-banner-3.png";
import forgetPasswordicon from "../assets/forgetPasswordicon.png";
import succesIcon from "../assets/succesIcon.png";
import onboardingscreen1 from "../assets/onboarding-screen1.png";
import onboardingscreen2 from "../assets/onboarding-screen2.png";
import onboardingscreen3 from "../assets/onboarding-screen3.png";
import onboardingscreen4 from "../assets/onboarding-screen4.png";
import heroimagebg from "../assets/hero-image-bg.png";
import heroimage from "../assets/hero-image.png";
import searchIcon from "../assets/searchIcon.png";
import ACrepair from "../assets/AC-repair.png";
import plumbing from "../assets/plumbing.png";
import Electrical from "../assets/Electrical.png";
import Housepainting from "../assets/Housepainting.png";
import CCTV from "../assets/CCTV.png";
import Modular from "../assets/Modular.png";
import Shadeinstalltion from "../assets/Shadeinstalltion.png";
import furniture from "../assets/furniture.png";
import mostdemanding1 from "../assets/mostdemanding1.png";
import mostdemanding2 from "../assets/mostdemanding2.png";
import mostdemanding3 from "../assets/mostdemanding3.png";
import offerimage1 from "../assets/offerimage-1.png";
import offerimage2 from "../assets/offerimage-2.png";
import offerimage3 from "../assets/offerimage-3.png";
import leftcircle from "../assets/leftcircle.png";
import rightcircle from "../assets/rightcircal.png";
import choosebar from "../assets/choosebar.png";
import Aboutfast from "../assets/Aboutfast.png";
import yellowdone from "../assets/yellowdone.png";
import shoote from "../assets/shoote.png";
import eyemark from "../assets/eyemark.png";
import bluesqure from "../assets/bluesqure.png";
import greenqure from "../assets/greensqure.png";
import AboutWhoWe from "../assets/AboutWhoWe.png";
import howitworks1 from "../assets/howitworks1.png";
import howitworks2 from "../assets/howitworks2.png";
import howitworks3 from "../assets/howitworks3.png";
import howitworks4 from "../assets/howitworks4.png";
import howitworks5 from "../assets/howitworks5.png";
import howitworks6 from "../assets/howitworks6.png";
import howitworks7 from "../assets/howitworks7.png";
import howitworks8 from "../assets/howitworks8.png";
import howitworks9 from "../assets/howitworks9.png";
import subscribenewsletter from "../assets/subscribenewsletter.png";
import telegramicon from "../assets/telegramicon.png";
import subscribemask from "../assets/subscribemask.png";
import subscribemask2 from "../assets/subscribemask2.png";
import bluebar from "../assets/bluebar.png";
import rightmoon from "../assets/rightmoon.png";
import leftmoon from "../assets/leftmoon.png";
import Hero from "../assets/Hero.png";
import Electrial from "../assets/Electrical.png";
import plumbingi from "../assets/plumbing (3).png";
import electrician from "../assets/electrician.png";
import carpentry from "../assets/carpentry.png";
import civil from "../assets/civil.png";
import others from "../assets/others.png";
import Hamburgure from "../assets/Hamburgure.png";
import painting from "../assets/painting.png";
import serviceitem from "../assets/service-item.png";
import rattingstar from "../assets/rattingstar.png";
import leftcard from '../assets/left-card.png'
import leftcardicon from '../assets/leftcard-icon.png'
import leftcards2 from '../assets/left-cards-2.png'
import leftcards3 from '../assets/left-cards-3.png'
import banner404 from '../assets/404banner.png'
import contactLineBar from '../assets/contact-linebar.png'
import contactSectionDots from '../assets/contact-section-dots.png'
import EnquiryHero from '../assets/EnquiryHero.png'
import totleBooking from '../assets/totleBooking.png'
import open from '../assets/open.png'
import Eactive from '../assets/active.png'
import done from '../assets/done.png'

export default {
  totleBooking,
  open,
  Eactive,
  done,
  contactSectionDots,
  EnquiryHero,
  contactLineBar,
  banner404,
  leftcards3,
  leftcards2,
  leftcard,
  leftcardicon,
  serviceitem,
  rattingstar,
  painting,
  Electrial,
  electrician,
  plumbingi,
  carpentry,
  civil,
  others,
  Hamburgure,
  Hero,
  rightmoon,
  leftmoon,
  bluebar,
  subscribemask2,
  telegramicon,
  subscribemask,
  subscribenewsletter,
  howitworks1,
  howitworks2,
  howitworks3,
  howitworks4,
  howitworks5,
  howitworks6,
  howitworks7,
  howitworks8,
  howitworks9,
  AboutWhoWe,
  bluesqure,
  greenqure,
  shoote,
  eyemark,
  yellowdone,
  Aboutfast,
  offerimage1,
  choosebar,
  leftcircle,
  rightcircle,
  offerimage2,
  offerimage3,
  mostdemanding1,
  mostdemanding2,
  mostdemanding3,
  ACrepair,
  plumbing,
  Electrical,
  Housepainting,
  CCTV,
  Modular,
  Shadeinstalltion,
  furniture,
  searchIcon,
  heroimage,
  heroimagebg,
  onboardingscreen1,
  onboardingscreen2,
  onboardingscreen3,
  onboardingscreen4,
  succesIcon,
  forgetPasswordicon,
  Loginbanner1,
  Loginbanner2,
  Loginbanner3,
  MainLogo,
  facebookicon,
  googleicon,
  iphoneicon,
};
